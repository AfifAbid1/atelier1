#include "fonction.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "callbacks.h"////
#include <gtk/gtk.h>

//recherche d existance
/*int rech(int id)
{
    FILE *f;
    menu repas ;

    F=fopen("src/menus.txt","r");
    do
    {
        fscanf(f," %d %d %d %d %d %s %s %s \n",repas.id,repas.date.jour,repas.date.mois ,repas.date.annee,repas.type , repas.entree,repas.plat_principale,repas.dessert);
        //fflush(stdin);
        if(repas.id==id)
        {
            fclose(F);
            return 1 ;
        }
    }while(!feof(F));
    fclose(F);
    return -1 ;
}*/
//ajouter
void ajouternour (menu repas ,char fichier[])
{
    FILE *f;
    f =fopen("Menu.txt","a+");

if (f!=NULL)
{
    fprintf (f,"%d %d %d %d %d %s %s %s \n",repas.id,repas.date.jour,repas.date.mois ,repas.date.annee,repas.type , repas.entree,repas.plat_principale,repas.dessert);
    fclose (f);
}
}
//modifier
void modifiernour (menu repas, char fichier[])
{
    
    menu repas2 ;
    FILE *f ,*g;
    f=fopen ("Menu.txt","r");
    g=fopen ("menu_modif.txt","a");
    if ((f!=NULL)&&(g!=NULL))
    {
        while (fscanf(f,"%d %d %d %d %d %s %s %s \n",&repas2.id,&repas2.date.jour,&repas2.date.mois ,&repas2.date.annee,&repas2.type ,repas2.entree,repas2.plat_principale,repas2.dessert)!=EOF)//end of file
       {
           if (repas.id==repas2.id)
           {
               fprintf(g,"%d %d %d %d %d %s %s %s \n",repas.id,repas.date.jour,repas.date.mois ,repas.date.annee,repas.type , repas.entree,repas.plat_principale,repas.dessert);
           }
           else
               {
                   fprintf(g,"%d %d %d %d %d %s %s %s \n",repas2.id,repas2.date.jour,repas2.date.mois ,repas2.date.annee,repas2.type , repas2.entree,repas2.plat_principale,repas2.dessert);
               }
           }
    }
    fclose (f);
    fclose (g);
    remove ("Menu.txt");
    rename("menu_modif.txt","Menu.txt");
}
//supprimer
void supprimenour (int id, char fichier[])
{
    menu repas2;
    FILE *f ,*g;
    f=fopen ("Menu.txt","r");
    g=fopen ("menu_supp.txt","a");
    if (f==NULL||g==NULL)
        return;
    else
    {
        while (fscanf(f,"%d %d %d %d %d %s %s %s \n",&repas2.id,&repas2.date.jour,&repas2.date.mois ,&repas2.date.annee,&repas2.type ,repas2.entree,repas2.plat_principale,repas2.dessert)!=EOF)
        {
            if (id!=repas2.id)
            {
                fprintf(g,"%d %d %d %d %d %s %s %s \n",repas2.id,repas2.date.jour,repas2.date.mois ,repas2.date.annee,repas2.type , repas2.entree,repas2.plat_principale,repas2.dessert);
            }
        }
        fclose(f);
        fclose (g);
        remove ("Menu.txt");//esm fichier Menu mch menu
        rename ("menu_supp.txt","Menu.txt");
        }
}
//recherche
menu cherchenour(int id,char fichier[])
{
    menu repas2;
    FILE *f;
    f=fopen(fichier,"r"); //ajouter sans supprimer
    if (f!=NULL)
    {

        while (fscanf (f,"%d %d %d %d %d %s %s %s \n",&repas2.id,&repas2.date.jour,&repas2.date.mois ,&repas2.date.annee,&repas2.type ,repas2.entree,repas2.plat_principale,repas2.dessert)!=EOF)

        {
            if (repas2.id==id)
                return repas2 ;

        }
        fclose (f);
    }
    return repas2;
}

enum
{
ID,
DATE,
ENTREE,
PLAT_PRINCIPALE,
DESSERT,
TYPE,
COLUMNS

};
//afficher 
void affichenour (GtkWidget *liste )
{ 
menu m;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char chid[20];
	char chdate[11];
	char chtype[20];
	
	
	store=gtk_tree_view_get_model(liste);
	FILE *f;
	
if (store==NULL)
{
		renderer=gtk_cell_renderer_text_new();////renderer
		column = gtk_tree_view_column_new_with_attributes("Id",renderer,"text",ID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		gtk_tree_view_column_set_expand(column,TRUE);
		

		renderer=gtk_cell_renderer_text_new();////renderer
		column = gtk_tree_view_column_new_with_attributes("date",renderer,"text",DATE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		gtk_tree_view_column_set_expand(column,TRUE);

		renderer=gtk_cell_renderer_text_new();////renderer
		column = gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		gtk_tree_view_column_set_expand(column,TRUE);
		
		renderer=gtk_cell_renderer_text_new();////renderer	     
		column=gtk_tree_view_column_new_with_attributes("Entree",renderer,"text",ENTREE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		gtk_tree_view_column_set_expand(column,TRUE);

		renderer=gtk_cell_renderer_text_new();////renderer
		column = gtk_tree_view_column_new_with_attributes("Plat_principale",renderer,"text",PLAT_PRINCIPALE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		gtk_tree_view_column_set_expand(column,TRUE);

		renderer=gtk_cell_renderer_text_new();////renderer
		column = gtk_tree_view_column_new_with_attributes("Dessert",renderer,"text",DESSERT,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		gtk_tree_view_column_set_expand(column,TRUE);
}
	
		
		
		store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);//gtk_list_store_new
	
 	
	f=fopen ("Menu.txt","r");
	if (f!=NULL)
	{ 
		f=fopen ("Menu.txt","a+");
		while (fscanf(f,"%d %d %d %d %d %s %s %s \n",&m.id,&m.date.jour,&m.date.mois ,&m.date.annee,&m.type ,m.entree,m.plat_principale,m.dessert)!=EOF)
		{ 
	sprintf(chid,"%d",m.id);//itoa() n'est pas disponible sous Linux vous devez travailler avec sprintf(chaine,"format",entier);
	sprintf(chdate,"%d/%d/%d",m.date.jour,m.date.mois,m.date.annee);////
	
	if (m.type==1)
	strcpy(chtype,"petit déjeuner");
	else if (m.type==2)
	strcpy(chtype,"déjeuner");
	else if (m.type==3)
	strcpy(chtype,"diner");


	gtk_list_store_append(store,&iter);	
        gtk_list_store_set(store,&iter,ID,chid,DATE,chdate,TYPE,chtype,ENTREE,m.entree,PLAT_PRINCIPALE,m.plat_principale,DESSERT,m.dessert,-1);
		}
		fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));//gtk_tree_view_set_model
	g_object_unref(store);//g_object_unref	
		}
		}
   
//meilleur menu 
/*void meilleur_menu()
{   char* temps[3];
temps[0]="Petit Dej";
temps[1]="Dejeuner";
temps[2]="Diner";
float min;
int posMin=0;
int i;    
menu m;
FILE *f ;
FILE *g;
    
f= fopen("dechets.txt","r");
g= fopen("menu.txt","r");  
char c;
int nbs=0;
while((c=fgetc(f))!=EOF)
	if (c == '\n')
		nbs++;
fseek(f,0,SEEK_SET);
dechet * d = malloc(nbs*sizeof(dechet));

if(f != NULL || g != NULL)
    {   
	for (int i =0;i<nbs;i++)
	{
    	fscanf(f,"%d %d %f \n",&d[i].jd,&d[i].dd,&d[i].dkg);
	}
         min=d[0].dkg;
	
         for (int i=1;i<nbs;i++)
         {
            if (d[i].dkg < min )
            {
            min = d[i].dkg;
	     posMin=i;
            }
	  }

         

        while(fscanf(g,"%d  %d  %d  %d  %d  %s %s %s \n",&m.id,&m.date.jour,&m.date.mois,&m.date.annee,&m.type,m.entree,m.plat_principale,m.dessert)!=EOF)
        {
            if (m.date.jour == d[posMin].jd && m.type == d[posMin].dd )
       		    {  printf("N° menu: \t %d \n",m.id);
           printf("date d'ajout:\t %d/%d/%d \n",m.date.jour,m.date.mois,m.date.annee);       
 
         printf("le contenu:\t %s / %s / %s \n",m.entree,m.plat_principale,m.dessert);
           printf("le temps du jour est : %s \n",temps[m.type-1]);
	   printf("avec un dechet de : %5.2f \n",d[posMin].dkg);
          
        }
	else 
      printf("not found");
    	}
     
   
    fclose(g);
    fclose(f);
}
else
fprintf(stderr,"fichiers introuvable\n");
}*/














