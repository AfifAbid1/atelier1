#ifndef FONCTION_H_
#define FONCTION_H_
#include <gtk/gtk.h>
typedef struct 
{ 
int jour ;
int mois ;
int annee ;
}date;

typedef struct 
{
int id;
date date ;
char entree[20];
char plat_principale[20];
char dessert[20];
int type;
}menu;
typedef struct 
{
int jd ;
int dd;
float dkg;
}dechet; 

void ajouternour(menu repas,char fichier[]);
void modifiernour( menu repas,char fichier[]);
void supprimenour(int id,char fichier[]);
void affichenour (GtkWidget *liste);
menu cherchenour(int id ,char fichier[]);
//void meilleur_menu ();
#endif 
