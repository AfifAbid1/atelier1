#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h" 
/*___________________ ajouter _______________________*/
int t=0,x=1,y=0;
	//les checkbuttons
	//_______________________________
void on_checktype1_toggled                  (GtkToggleButton *togglebutton, gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{t=1;}
}
void on_checktype2_toggled                  (GtkToggleButton *togglebutton,gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{t=2;}
}
void on_checktype3_toggled                  (GtkToggleButton *togglebutton,gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{t=3;}
}
	//_______________________________
void on_ajout_clicked                       (GtkWidget       *objet , gpointer         user_data)
{
	//--------declaration---------
GtkWidget *enregistrer ;//windows
GtkWidget *input;//entry
GtkWidget *jour,*mois,*annee;//spinbutton
GtkWidget *idmodif;//combobox dynamique 
menu m;
char ch[20];

	//------les entry------
input = lookup_widget(objet, "idajout") ;
m.id=atoi (gtk_entry_get_text(GTK_ENTRY(input))); 
input=lookup_widget(objet, "entree");
strcpy(m.entree,gtk_entry_get_text(GTK_ENTRY(input)));
input=lookup_widget(objet, "pp");
strcpy(m.plat_principale,gtk_entry_get_text(GTK_ENTRY(input)));
input=lookup_widget(objet, "dessert");
strcpy(m.dessert,gtk_entry_get_text(GTK_ENTRY(input)));
	//------les spinbuttons------
jour=lookup_widget(objet, "jour"); 
mois=lookup_widget(objet, "mois"); 
annee=lookup_widget(objet, "annee"); 
//recuperer les valeurs des spinbutton en utilisant la fct gtk_spin_button_get_value_as_int qui retourne l'entier choisi par user
m.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
m.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
m.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));
	//l'ajout
if (t==1)
m.type=1;
if (t==2)
m.type=2;
if (t==3)
m.type=3;
ajouternour(m,"menu.txt");
	//-------combobox dynamique-------
sprintf(ch,"%d",m.id);
gtk_combo_box_append_text  (GTK_COMBO_BOX (idmodif),ch );
enregistrer=create_enregistrer();
gtk_widget_show(enregistrer);

}

/////////////////////////////////fin ajout ///////////////////////////


void on_modifier_clicked                    (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *modifier;
modifier=create_modifier();
gtk_widget_show(modifier);
}




/*_________________________supprimer_________________________*/
	//-------bouttons radio (oui/non)-------
void on_radiobuttonoui_toggled              (GtkToggleButton *togglebutton, gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
x=1;
}


void on_radiobuttonnon_toggled              (GtkToggleButton *togglebutton, gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
x=2;
}
//////////////////////////////////////////////////
char msg[50]="";
int id;
GtkWidget* output_sup ;

void
on_supp_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget* input;
GtkWidget *supprimer;


input =lookup_widget(objet,"idsupp");
output_sup=lookup_widget(objet,"label51s");
id=atoi (gtk_entry_get_text(GTK_ENTRY(input)));
supprimer=create_supprimer();
gtk_widget_show (supprimer);

}


void
on_valid_clicked                (GtkWidget       *objet, gpointer         user_data)
{
GtkWidget *supp;
if (x==1)
{
supprimenour(id,"menu.txt");
strcpy (msg,"suppression effectuée avec succès !! ");

}
else if (x==2)
{ 
strcpy (msg,"suppression non effectuée !!");

}

gtk_label_set_text(GTK_LABEL(output_sup),msg);
supp=lookup_widget(objet,"supprimer");
gtk_widget_destroy(supp);

}

//////////////////////fin supprimer///////////////////


//________________________chercher_________________________
menu m1;
void on_chercher_clicked                    (GtkWidget       *objet, gpointer         user_data)
{GtkWidget *chercher;
GtkWidget *input ,*output;
char ch[20],ch1[20],ch2[20],ch3[20];
menu m;
int id1;
input=lookup_widget(objet,"idcher");
id1=atoi (gtk_entry_get_text(GTK_ENTRY(input)));
m1=cherchenour(id1,"Menu.txt");
if (m1.id==id1)
{
output=lookup_widget(objet,"label52cher");
gtk_label_set_text(GTK_LABEL(output),"le menu existe !!");
chercher=create_chercher();
gtk_widget_show (chercher);

}
else 
{output=lookup_widget(objet,"label52cher");
gtk_label_set_text(GTK_LABEL(output),"le menu n'existe pas !!");}

}
////////////////////////////////////////////////////////////////////////////////////////////
void
on_chercher_show                       (GtkWidget       *objet,gpointer         user_data)
{
GtkWidget *output;
char ch[20],ch1[20],ch2[20],ch3[20];


output=lookup_widget(objet,"entree1");
gtk_label_set_text(GTK_LABEL(output),m1.entree);
output=lookup_widget(objet,"pp1");
gtk_label_set_text(GTK_LABEL(output),m1.plat_principale);
output=lookup_widget(objet,"dessert1");
gtk_label_set_text(GTK_LABEL(output),m1.dessert);
if (m1.type==1)
strcpy (ch,"petit dejeuner");
if (m1.type==2)
strcpy (ch,"dejeuner");
if (m1.type==3)
strcpy (ch,"diner");
output=lookup_widget(objet,"type1");
gtk_label_set_text(GTK_LABEL(output),ch);

output=lookup_widget(objet,"jour1");
sprintf(ch1,"%d",m1.date.jour);
gtk_label_set_text(GTK_LABEL(output),ch1);

output=lookup_widget(objet,"mois1");
sprintf(ch2,"%d",m1.date.mois);
gtk_label_set_text(GTK_LABEL(output),ch2);

output=lookup_widget(objet,"annee1");
sprintf(ch3,"%d",m1.date.annee);
gtk_label_set_text(GTK_LABEL(output),ch3);
}
//_________________retour à l'acceuil______________
void on_retour_clicked   (GtkWidget       *objet,gpointer         user_data)
{
 GtkWidget *chercher;
chercher=lookup_widget(objet,"chercher");
gtk_widget_destroy(chercher);
}


/////////////////fin chercher///////////////

void
on_meilleur_menu_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}

//___________________________afficher__________________________________

/*void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *id;
gchar *date;
gchar *type;
gchar *chentree;
gchar *chplat_principale;
gchar *chdessert;
	char chid[20];
	char chdate[30];
	char chtype[10];
menu m;
GtkTreeModel *model =gtk_tree_view_get_model(treeview);
	if (gtk_tree_view_get_model(model))//////////////////
{
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&date,2,&type,3,&chentree,4,&chplat_principale,5,&chdessert,-1);

	sprintf(chid,"%d",m.id);//itoa() n'est pas disponible sous Linux vous devez travailler avec sprintf(chaine,"format",entier);
	sprintf(chdate,"%d/%d/%d",m.date.jour,m.date.mois,m.date.annee);////
	


	if (m.type==1)
	strcpy(chtype,"petit déjeuner");
	else if (m.type==2)
	strcpy(chtype,"déjeuner");
	else if (m.type==3)
	strcpy(chtype,"diner");
	strcpy(chid,id);
	strcpy(chdate,date);
	strcpy(chtype,type);
	strcpy(m.entree,chentree);
	strcpy(m.plat_principale,chplat_principale);
	strcpy(m.dessert,chdessert);
	supprime(m.id,"menu.txt");
	affiche(treeview);}


}*/


void on_afficher_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview1,*home;

home=lookup_widget (objet, "home");
treeview1 = lookup_widget (home, "treeview1");
affichenour(treeview1);
}
	////////////////////fin afficher//////////////////








//____________________ok enregistrer______________________

void on_ok_clicked     (GtkWidget      *objet,gpointer         user_data)
{
GtkWidget *enregistrer;
enregistrer=lookup_widget(objet,"enregistrer");
gtk_widget_destroy(enregistrer);
}







///////////////////////window modifier///////////////

/*----------------les bouttons radios--------------*/

/*void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
y=1;
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
y=2;
}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
y=3;
}*/

void
on_chercher2_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input,*output;

int id2 ;
menu m2;
char ch1[50],ch2[50];

input = lookup_widget(objet, "idmodif1") ;
id2=atoi (gtk_entry_get_text(GTK_ENTRY(input)));
m2=cherchenour(id2,"Menu.txt");
if (m2.id==id2)
{

output=lookup_widget(objet,"entry2pd");
gtk_entry_set_text(GTK_ENTRY(output),m2.entree);

output=lookup_widget(objet,"entry3dej");
gtk_entry_set_text(GTK_ENTRY(output),m2.plat_principale);

output=lookup_widget(objet,"entry4diner");
gtk_entry_set_text(GTK_ENTRY(output),m2.dessert);

output=lookup_widget(objet,"label98");
sprintf(ch1,"%d/%d/%d",m2.date.jour,m2.date.mois,m2.date.annee);
gtk_label_set_text(GTK_ENTRY(output),ch1);//gtk label set mch gtk entry set -_-


if (m2.type==1)
{strcpy(ch2,"petit dejeuner");}
if (m2.type==2)
{strcpy(ch2,"dejeuner");}
if (m2.type==3)
{strcpy(ch2,"diner");}
output=lookup_widget(objet,"label99");
gtk_label_set_text(GTK_LABEL(output),ch2);//gtk label set mch gtk entry set -_-
output=lookup_widget(objet,"label71cher");
gtk_label_set_text(GTK_LABEL(output),"le menu existe !!");///GTK_LABEL mch GTK_ENTRY -_-

}
else 
{output=lookup_widget(objet,"label71cher");
gtk_label_set_text(GTK_LABEL(output),"le menu n'existe pas !!");}

}

void
on_annuler_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *modifier;
modifier=lookup_widget(objet,"modifier");
gtk_widget_destroy(modifier);
}


void
on_enregistrer_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *enregistrer ,*jour3,*mois3,*annee3;
menu m2;
GtkWidget *input;
char ch1[50],ch2[50],chtemps[20];

input = lookup_widget(objet, "idmodif1") ;
m2.id=atoi (gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(objet,"entry2pd");
strcpy(m2.entree,gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(objet,"entry3dej");
strcpy(m2.plat_principale,gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(objet,"entry4diner");
strcpy(m2.dessert,gtk_entry_get_text(GTK_ENTRY(input)));


m2.type=y;

jour3=lookup_widget(objet, "jour3"); 
mois3=lookup_widget(objet, "mois3"); 
annee3=lookup_widget(objet, "annee3"); 
//recuperer les valeurs des spinbutton en utilisant la fct gtk_spin_button_get_value_as_int qui retourne l'entier choisi par user
m2.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour3));
m2.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois3));
m2.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee3));

		//COMBOBOX

		input=lookup_widget(objet,"combobox1");
		strcpy(chtemps,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input)));
		m2.type=atoi(chtemps);

modifiernour(m2,"menu.txt");

enregistrer=lookup_widget(objet,"modifier");
gtk_widget_destroy(enregistrer);
}
	///////////////////fin modifier//////////////////


//___________________quitter l'acceuil__________________
void on_quitter_clicked    (GtkWidget      *objet,gpointer         user_data)
{
GtkWidget *home;
home=lookup_widget(objet,"home");
gtk_widget_destroy(home);
}




void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_buttonretour_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}






