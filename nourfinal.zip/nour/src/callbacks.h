#include <gtk/gtk.h>


void
on_ajout_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);//

void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checktype3_toggled                  (GtkToggleButton *togglebutton,//
                                        gpointer         user_data);

void
on_supp_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);//

void
on_chercher_clicked                    (GtkWidget       *objet,//
                                        gpointer         user_data);

void
on_checktype1_toggled                  (GtkToggleButton *togglebutton,//
                                        gpointer         user_data);

void
on_meilleur_menu_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_quitter_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);//

void
on_checktype2_toggled                  (GtkToggleButton *togglebutton,//
                                        gpointer         user_data);

void
on_radiobuttonoui_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);//

void
on_radiobuttonnon_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);//

void
on_valid_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);//
                  

void
on_ok_clicked                          (GtkWidget      *objet,
                                        gpointer         user_data);//

void
on_retour_clicked                      (GtkWidget       *objet,//
                                        gpointer         user_data);

void
on_chercher2_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_annuler_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_enregistrer_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonretour_clicked                (GtkButton       *button,
                                        gpointer         user_data);



void
on_chercher_show                       (GtkWidget       *objet,gpointer         user_data);/////////////////
