#include <gtk/gtk.h>


void
on_afficher_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Modifier_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Ajouter_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Supprimer_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_rechercher_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_utilisateurbutton_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajout_clicked                       (GtkButton       *button,
                                        gpointer         user_data);






void
on_rechercher_show                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonplus_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonquit_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_login_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonajout_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
