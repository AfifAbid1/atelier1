#include "fonction.h"
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>

enum
{
	ENOM,
	EPRENOM,
	ECIN,
	EJOUR,
	EMOIS,
	EANNEE,
	EMOTDEPASSE,
	ESEXE,
	EESPRIT,
	COLUMNS,
};
GtkListStore *adstore;
GtkTreeViewColumn *adcolumn;
GtkCellRenderer *cellad;
FILE *f;

void afficher(GtkTreeView *l)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter  iter;
	GtkListStore *store;
	char nom[20];
	char prenom[20];
	char CIN[20];
	char jour[20];
	char mois[20];
	char annee[20];
	char motdepasse[20];
	char sexe[20];
	char esprit[20];

store=NULL;
FILE *f;
store=GTK_LIST_STORE(gtk_tree_view_get_model(l));
if (store==NULL)
{	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("nom",renderer, "text" ,ENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(l), column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("prenom",renderer, "text" ,EPRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(l), column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("CIN",renderer, "text" ,ECIN,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(l), column);
	
	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("jour",renderer, "text" ,EJOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(l), column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("mois",renderer, "text" ,EMOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(l), column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("annee",renderer, "text" ,EANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(l), column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("motdepasse",renderer, "text" ,EMOTDEPASSE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(l), column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("sexe",renderer, "text" ,ESEXE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(l), column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("esprit",renderer, "text" ,EESPRIT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(l), column);

}

store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f=fopen("fichier.txt","a+");
if (f==NULL)
{
	return;
}
else
{
f=fopen("fichier.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s",nom,prenom,CIN,jour,mois,annee,motdepasse,sexe,esprit)!=EOF)
{
         gtk_list_store_append(store, &iter);
	 gtk_list_store_set(store, &iter,
                            ENOM,nom,
                            EPRENOM,prenom,
                            ECIN,CIN,
			    EJOUR,jour,	
                            EMOIS,mois,
                            EANNEE,annee,
                            EMOTDEPASSE,motdepasse,
                            ESEXE,sexe,
                            EESPRIT,esprit,
                            -1);}
        fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW(l), GTK_TREE_MODEL(store));
	g_object_unref (store);
	}

}


void ajouter(etudiant e,char fichier[])
{
    FILE *f;
    f=fopen(fichier,"a+");
    if (f!=NULL)
    {
    fprintf(f,"%s %s %s %d %d %d %s %s %d %d %d %d %d \n",e.nom,e.prenom,e.CIN,e.jour,e.mois,e.annee,e.motdepasse,e.sexe,e.esprit[0],e.esprit[1],e.esprit[2],e.esprit[3],e.esprit[4]);
    }
    fclose(f);
    

}


void supprimer_etudiant(char CIN[],char fichier[])
{
    FILE *f1=NULL;
    FILE *f2=NULL;
    etudiant e;
    f1=fopen("fichier.txt","r");
    f2=fopen("auxil.txt","a");
    while(fscanf(f1,"%s %s %s %d %d %d %s %s %d %d %d %d %d",e.nom,e.prenom,e.CIN,&e.jour,&e.mois,&e.annee,e.motdepasse,e.sexe,&e.esprit[0],&e.esprit[1],&e.esprit[2],&e.esprit[3],&e.esprit[4])!=EOF)
    {
        if (strcmp(CIN,e.CIN)!=0)
            fprintf(f2,"%s %s %s %d %d %d %s %s %d %d %d %d %d",e.nom,e.prenom,e.CIN,e.jour,e.mois,e.annee,e.motdepasse,e.sexe,e.esprit[0],e.esprit[1],e.esprit[2],e.esprit[3],e.esprit[4]);
    }
    fclose(f1);
    fclose(f2);
    remove("fichier.txt");
    rename("auxil.txt",fichier);

}


void modifier(char CIN[],etudiant a,char fichier[])
{
    FILE *f1,*f2;
    etudiant b;
    f1=fopen("fichier.txt","r");
    f2=fopen("auxil.txt","w+");
    while(fscanf(f1,"%s %s %s %d %d %d %s %s %d %d %d %d %d",b.nom,b.prenom,b.CIN,&b.jour,&b.mois,&b.annee,b.motdepasse,b.sexe,&b.esprit[0],&b.esprit[1],&b.esprit[2],&b.esprit[3],&b.esprit[4])!=EOF)
    {
        if(strcmp(CIN,b.CIN)!=0)
          fprintf(f2,"%s %s %s %d %d %d %s %s %d %d %d %d %d",a.nom,a.prenom,a.CIN,a.jour,a.mois,a.annee,a.motdepasse,a.sexe,a.esprit[0],a.esprit[1],a.esprit[2],a.esprit[3],a.esprit[4]);
        else
          fprintf(f2,"%s %s %s %d %d %d %s %s %d %d %d %d %d\n",b.nom,b.prenom,b.CIN,b.jour,b.mois,b.annee,b.motdepasse,b.sexe,b.esprit[0],b.esprit[1],b.esprit[2],b.esprit[3],b.esprit[4]);
    }
    fclose(f1);
    fclose(f2);
    remove("fichier.txt");
    rename("auxil.txt","fichier.txt");
}


etudiant chercher_etudiant(char CIN[],char fichier[])
{
    FILE *f=NULL;
    etudiant e;
    strcpy(e.CIN,"-1");
    strcpy(e.nom,"-1");
    f=fopen("fichier.txt","r");
    while(fscanf(f,"%s %s %s %d %d %d %s %s %d %d %d %d %d",e.nom,e.prenom,e.CIN,&e.jour,&e.mois,&e.annee,e.motdepasse,e.sexe,&e.esprit[0],&e.esprit[1],&e.esprit[2],&e.esprit[3],&e.esprit[4])!=EOF)
    {
        if (strcmp(CIN,e.CIN)==0)
            return e;
            fclose(f);
    }
    return e;
    fclose(f);
}



void ajout(utilisateur u,char fichier[])
{
    FILE *f;
    f=fopen("utilisateur.txt","a+");
    if (f!=NULL)
    {
    fprintf(f,"%s %s %s\n",u.id,u.key,u.type);
    }
    fclose(f);
    

}


utilisateur chercher(char id[],char key[],char fichier[])
{
    FILE *f=NULL;
    utilisateur u;
    strcpy(u.id,"-1");
    strcpy(u.key,"-1");
    f=fopen("utilisateur.txt","r");
    while(fscanf(f,"%s %s %s",u.id,u.key,u.type)!=EOF)
    {
        if ((strcmp(id,u.id)==0)&&(strcmp(key,u.key)==0))
            return u;
            fclose(f);
    }
    return u;
    fclose(f);
}


















