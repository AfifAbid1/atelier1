#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
int r,x,c=0;
int t[5];
void
on_afficher_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
GtkWidget *Bienvenue;
Bienvenue=lookup_widget(objet_graphique,"Bienvenue");
treeview1=lookup_widget(Bienvenue,"treeview1");
afficher(GTK_TREE_VIEW(treeview1));
}


void
on_checkbutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
t[4]=1;
}


void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
t[3]=1;
}


void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
t[2]=1;
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
t[1]=1;
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
r=2;
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
r=1;
}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
t[0]=1;
}


void
on_Modifier_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
etudiant e;
GtkWidget *nom,*prenom,*CIN, *jour,*mois,*annee, *motdepasse, *sexe, *esprit;
nom=lookup_widget(objet_graphique,"entryNom");
prenom=lookup_widget(objet_graphique,"entryPrenom");
CIN=lookup_widget(objet_graphique,"entryCIN");
jour=lookup_widget(objet_graphique,"jour");
mois=lookup_widget(objet_graphique,"mois");
annee=lookup_widget(objet_graphique,"annee");
motdepasse=lookup_widget(objet_graphique,"entrymdp");
sexe=lookup_widget(objet_graphique,"sexe");
esprit=lookup_widget(objet_graphique,"esprit");
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(e.motdepasse,gtk_entry_get_text(GTK_ENTRY(motdepasse)));
strcpy(e.CIN,gtk_entry_get_text(GTK_ENTRY(CIN)));
e.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if (r==1)
 strcpy(e.sexe,"Homme");
else 
 strcpy(e.sexe,"Femme");
if(t[0]==1)
e.esprit[0]=1;
else
e.esprit[0]=0;
if(t[1]==1)
e.esprit[1]=2;
else
e.esprit[1]=0;
if(t[2]==1)
e.esprit[2]=3;
else
e.esprit[2]=0;
if(t[3]==1)
e.esprit[3]=4;
else
e.esprit[3]=0;
if(t[4]==1)
e.esprit[4]=5;
else
e.esprit[4]=0;
modifier(CIN,e,"fichier.txt");
}


void
on_Ajouter_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
etudiant e;
GtkWidget *nom,*prenom,*CIN, *jour,*mois,*annee, *motdepasse, *sexe, *esprit;
nom=lookup_widget(objet_graphique,"entryNom");
prenom=lookup_widget(objet_graphique,"entryPrenom");
CIN=lookup_widget(objet_graphique,"entryCIN");
jour=lookup_widget(objet_graphique,"jour");
mois=lookup_widget(objet_graphique,"mois");
annee=lookup_widget(objet_graphique,"annee");
motdepasse=lookup_widget(objet_graphique,"entrymdp");
sexe=lookup_widget(objet_graphique,"sexe");
esprit=lookup_widget(objet_graphique,"esprit");
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(e.motdepasse,gtk_entry_get_text(GTK_ENTRY(motdepasse)));
strcpy(e.CIN,gtk_entry_get_text(GTK_ENTRY(CIN)));
e.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
e.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
e.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if (r==1)
 strcpy(e.sexe,"Homme");
else 
 strcpy(e.sexe,"Femme");
if(t[0]==1)
e.esprit[0]=1;
else
e.esprit[0]=0;
if(t[1]==1)
e.esprit[1]=2;
else
e.esprit[1]=0;
if(t[2]==1)
e.esprit[2]=3;
else
e.esprit[2]=0;
if(t[3]==1)
e.esprit[3]=4;
else
e.esprit[3]=0;
if(t[4]==1)
e.esprit[4]=5;
else
e.esprit[4]=0;
ajouter(e,"fichier.txt");

}


void
on_Supprimer_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input,*output;
etudiant e;
char CIN[20];
input=lookup_widget(objet_graphique,"entryCIN2");
strcpy(CIN,gtk_entry_get_text(GTK_ENTRY(input)));
e=chercher_etudiant(CIN,"fichier.txt");
if(strcmp(CIN,e.CIN)==0)
{
output=lookup_widget(objet_graphique,"labelsupp");
gtk_label_set_text(GTK_LABEL(output),"etudiant supprimé");
supprimer_etudiant(CIN,"fichier.txt");

}
else
{
output=lookup_widget(objet_graphique,"labelsupp");
gtk_label_set_text(GTK_LABEL(output),"l'etudiant n'existe pas !!");
}
supprimer_etudiant(CIN,"fichier.txt");
}

etudiant e;
void
on_rechercher_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *rechercher,*input,*output;
char CIN[20];
input=lookup_widget(objet_graphique,"entryCIN2");
strcpy(CIN,gtk_entry_get_text(GTK_ENTRY(input)));
e=chercher_etudiant(CIN,"fichier.txt");
if(strcmp(CIN,e.CIN)==0)
{
output=lookup_widget(objet_graphique,"labeletudiant");
gtk_label_set_text(GTK_LABEL(output),"l'etudiant existe !!");
rechercher = create_rechercher ();
gtk_widget_show (rechercher);
}
else
{
output=lookup_widget(objet_graphique,"labeletudiant");
gtk_label_set_text(GTK_LABEL(output),"l'etudiant n'existe pas !!");
}
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* nom;
gchar* prenom;
gchar* CIN;
gchar* jour;
gchar* mois;
gchar* annee;
gchar* motdepasse;
gchar* sexe;
gchar* esprit;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model, &iter, path))
{
gtk_tree_model_get (GTK_TREE_MODEL(model),&iter,0,&nom, 1 ,&prenom, 2 , &CIN, 3 ,&jour, 4 ,&mois, 5 ,&annee, 6 ,motdepasse, 7 ,&sexe, 8 ,&esprit,-1);
afficher(treeview);
}

}

void
on_utilisateurbutton_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_valider_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ajout_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{

}



void
on_rechercher_show                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *output;
char ch1[20],ch2[20],ch3[20];
output=lookup_widget(objet_graphique,"labelNom");
gtk_label_set_text(GTK_LABEL(output),e.nom);
output=lookup_widget(objet_graphique,"labelPrenom");
gtk_label_set_text(GTK_LABEL(output),e.prenom);
output=lookup_widget(objet_graphique,"labelCIN");
gtk_label_set_text(GTK_LABEL(output),e.CIN);
output=lookup_widget(objet_graphique,"labelmdp");
gtk_label_set_text(GTK_LABEL(output),e.motdepasse);
output=lookup_widget(objet_graphique,"labelsexe");
gtk_label_set_text(GTK_LABEL(output),e.sexe);
output=lookup_widget(objet_graphique,"labeljour");
sprintf(ch1,"%d",e.jour);
gtk_label_set_text(GTK_LABEL(output),ch1);
output=lookup_widget(objet_graphique,"labelmois");
sprintf(ch2,"%d",e.mois);
gtk_label_set_text(GTK_LABEL(output),ch2);
output=lookup_widget(objet_graphique,"labelannee");
sprintf(ch3,"%d",e.annee);
gtk_label_set_text(GTK_LABEL(output),ch3);
}


void
on_buttonplus_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *windowajout;
windowajout = create_windowajout ();
gtk_widget_show (windowajout);
}


void
on_buttonquit_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *windowlogin,*Bienvenue;
windowlogin = create_windowlogin ();
gtk_widget_show (windowlogin);
Bienvenue=lookup_widget(objet_graphique,"Bienvenue");
gtk_widget_destroy(Bienvenue);
}


void
on_login_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input, *Bienvenue,*windowlogin;
utilisateur u;
char id[20],key[20];
input=lookup_widget(objet_graphique,"entryidentifiant");
input=lookup_widget(objet_graphique,"entrykey");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(key,gtk_entry_get_text(GTK_ENTRY(input)));
u=chercher(id,key,"utilisateur.txt");
if(strcmp("Administrateur",u.type)==0)
{
Bienvenue = create_Bienvenue ();
gtk_widget_show (Bienvenue);
windowlogin=lookup_widget(objet_graphique,"windowlogin");
gtk_widget_destroy(windowlogin);
}
else if(strcmp("technicien",u.type)==0)
c=2;
else if(strcmp("nutritioniste",u.type)==0)
c=3;
else if(strcmp("agent de stock",u.type)==0)
c=4;
else if(strcmp("agent de foyer",u.type)==0)
c=5;
else 
c=6;



}


void
on_buttonajout_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
utilisateur u;
GtkWidget *id,*key,*type;
id=lookup_widget(objet_graphique,"entryidentifiant1");
key=lookup_widget(objet_graphique,"entrykey1");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(u.key,gtk_entry_get_text(GTK_ENTRY(key)));
type=lookup_widget(objet_graphique , "comboboxadmin");
strcpy(u.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
ajout(u,"utilisateur.txt");

}

