#ifndef FONCTION_H_
#define FONCTION_H_
#include <gtk/gtk.h>
typedef struct 
{
    char nom[20];
    char prenom[20];
    char CIN[20];
    int jour;
    int mois;
    int annee;
    char motdepasse[20];
    char sexe[20];
    int esprit[5] ;
     
}etudiant;
typedef struct
{
char id[20];
char key[20];
char type[20];
}utilisateur;

void ajouter(etudiant e,char fichier[]);
void supprimer_etudiant(char CIN[],char fichier[]);
void modifier(char CIN[],etudiant a,char fichier[]);
etudiant chercher_etudiant(char CIN[],char fichier[]);
void afficher(GtkTreeView *l);
void ajout(utilisateur u,char fichier[]);
utilisateur chercher(char id[],char key[],char fichier[]);
#endif




