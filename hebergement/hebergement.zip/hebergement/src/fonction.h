#ifndef FONCTION_H_
#define FONCTION_H_
#include<gtk/gtk.h>

typedef struct Reclamation
{

char id[20];
char idrec[20];
char reclamation1[200];
int note;
char type[200];
}reclamation;

void ajouter(reclamation rec);
void modifier(reclamation rec);
void supprimer(reclamation rec);
int Chercher(GtkWidget* treeview1,char *l,char *nom);
void afficher_rec(GtkWidget* treeview1,char*l);
void afficher_rec1(GtkWidget* treeview1,char*l);
char* service_plus_reclame(char* l) ;
int exist(char *id);
#endif

