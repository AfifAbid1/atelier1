#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"

int x=1;
int verif = 0;
reclamation rec;


////////////////jawha behy//////////////////
void
on_button4_ajout_clicked               (GtkButton       *button,
                                        gpointer         user_data)

{
	GtkWidget *window3_reclamation;
	GtkWidget *window1_ajouter;

	window3_reclamation=lookup_widget(button,"window3_reclamation");

	gtk_widget_destroy(window3_reclamation);
	window1_ajouter=create_window1_ajouter();

	gtk_widget_show(window1_ajouter);
}


///////////////jawha behy/////////////
void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window3_reclamation;
	GtkWidget *window7_supprimer;

	window3_reclamation=lookup_widget(button,"window3_reclamation");

	gtk_widget_destroy(window3_reclamation);
	window7_supprimer=create_window7_supprimer();

	gtk_widget_show(window7_supprimer);
}

//////////////////jawha behy////////////
void
on_button1_modif_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window3_reclamation;
	GtkWidget *window5_modifier;

	window3_reclamation=lookup_widget(button,"window3_reclamation");

	gtk_widget_destroy(window3_reclamation);
	window5_modifier=create_window5_modifier();

	gtk_widget_show(window5_modifier);
}


////////////////jawha behy///////////////////
void
on_button3_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window3_reclamation;
	GtkWidget *window1_ajouter;

	window1_ajouter=lookup_widget(button,"window1_ajouter");

	gtk_widget_destroy(window1_ajouter);
	window3_reclamation=create_window3_reclamation();

	GtkWidget *treeview1,*treeview2;
	treeview1=lookup_widget(window3_reclamation,"treeview1");
	afficher_rec(treeview1,"fichier.txt");
	treeview2=lookup_widget(window3_reclamation,"treeview2");
	afficher_rec(treeview2,"fichier.txt");


	gtk_widget_show(window3_reclamation);

}


///////////////jawha behy//////////////////////
void
on_button3_annuler_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window3_reclamation;
	GtkWidget *window5_modifier;

	window5_modifier=lookup_widget(button,"window5_modifier");

	gtk_widget_destroy(window5_modifier);
	window3_reclamation=create_window3_reclamation();

	GtkWidget *treeview1,*treeview2;
	treeview1=lookup_widget(window3_reclamation,"treeview1");
	afficher_rec(treeview1,"fichier.txt");
	treeview2=lookup_widget(window3_reclamation,"treeview2");
	afficher_rec(treeview2,"fichier.txt");

	gtk_widget_show(window3_reclamation);
}

//////////////jawha behy////////////////////
void
on_button4_annuler_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window3_reclamation;
	GtkWidget *window7_supprimer;

	window7_supprimer=lookup_widget(button,"window7_supprimer");

	gtk_widget_destroy(window7_supprimer);
	window3_reclamation=create_window3_reclamation();

	GtkWidget *treeview1,*treeview2;
	treeview1=lookup_widget(window3_reclamation,"treeview1");
	afficher_rec(treeview1,"fichier.txt");
	treeview2=lookup_widget(window3_reclamation,"treeview2");
	afficher_rec(treeview2,"fichier.txt");
	verif = 0;
	gtk_widget_show(window3_reclamation);
}

////////////////////a corriger////////////////////////
void
on_button5_ajout_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *input1,*input2,*input3,*input4,*input5,*window1_ajouter,*p,*IDREC,*ID,*RECLAMATION,*p2,*output;

	window1_ajouter = lookup_widget(button,"window1_ajouter");
	
	char texte[100];

	p=lookup_widget(button,"treeview1");
	p2=lookup_widget(button,"treeview2");
//entries
	input1=lookup_widget(button,"entry4");
	input2=lookup_widget(button,"entry5");
	input3=lookup_widget(button,"comboboxentry1");
	input4=lookup_widget(button,"spinbutton1");
	input5=lookup_widget(button,"entry3");

//labels	
	IDREC=lookup_widget(button,"idreci");
	ID=lookup_widget(button,"idi");
	RECLAMATION=lookup_widget(button,"reclamationi");

//recuperation des données
	strcpy(rec.idrec,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(rec.id,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(rec.reclamation1,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(rec.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
	rec.note=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));



	//controle de saisie 

if(strcmp(rec.idrec,"")==0){
gtk_widget_show(IDREC);

}
else
{
gtk_widget_set_visible(IDREC,FALSE);

}
if(strcmp(rec.id,"")==0){
gtk_widget_show(ID);

}
else
{
gtk_widget_set_visible(ID,FALSE);

}

if(strcmp(rec.reclamation1,"")==0){
gtk_widget_show(RECLAMATION);

}
else
{
gtk_widget_set_visible(RECLAMATION,FALSE);
}

if(gtk_widget_get_visible(ID)==FALSE && gtk_widget_get_visible(IDREC)==FALSE && gtk_widget_get_visible(RECLAMATION)==FALSE){
if(	exist(rec.idrec)==1){
	sprintf(texte,"❌ Cet id existe \n");
	output = lookup_widget(button,"labelexiste");
	GdkColor color;
	gdk_color_parse ("#ff250d", &color);
	gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
    	gtk_label_set_text(GTK_LABEL(output),texte);/////////////////dima tben////////////////////
        afficher_rec(p,"fichier.txt");
        afficher_rec(p2,"fichier.txt");
}
else{
	ajouter(rec);
	afficher_rec(p,"fichier.txt");
	afficher_rec(p2,"fichier.txt");
		
//////////////////////////////////////////////////////////////////////////////////////

	GtkWidget *window3_reclamation;

	window1_ajouter=lookup_widget(button,"window1_ajouter");

	gtk_widget_destroy(window1_ajouter);

	//window3_reclamation=lookup_widget(button,"window3_reclamation");///
	window3_reclamation=create_window3_reclamation();
	GtkWidget *treeview1,*treeview2;
	treeview1=lookup_widget(window3_reclamation,"treeview1");
	afficher_rec(treeview1,"fichier.txt");
	treeview2=lookup_widget(window3_reclamation,"treeview2");
	afficher_rec(treeview2,"fichier.txt");
	gtk_widget_show(window3_reclamation);
}

}

}


////////////////jawha behy////////////////
void
on_radiobutton11_hebergement_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;}
}



///////////jawha behy///////////////////
void
on_radiobutton12_restauration_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=2;}
}


///////treeview/////////
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


//////////////////a corriger////////////////////

void
on_button5_modifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget  *input6,*output;
reclamation rec;
char id[20];
char texte[100];


input1 = lookup_widget(button,"entry5_id");
input2 = lookup_widget(button,"entry2");
input3 = lookup_widget(button,"radiobutton11_hebergement");
input4 = lookup_widget(button,"radiobutton12_restauration");
input5 = lookup_widget(button,"spinbutton2");
input6 = lookup_widget(button,"entry3_reclamation");


strcpy(rec.idrec,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(rec.id,gtk_entry_get_text(GTK_ENTRY(input2)));

rec.note = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (input5));

if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (input4))) strcpy(rec.type,"restauration");

if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (input3))) strcpy(rec.type,"hebergement"); 

strcpy(rec.reclamation1,gtk_entry_get_text(GTK_ENTRY(input6)));


if(exist(rec.idrec))
             {
		modifier(rec);
		GtkWidget *treeview1,*treeview2;
		GtkWidget *window3_reclamation;
		GtkWidget *window5_modifier;

		window5_modifier=lookup_widget(button,"window5_modifier");

		//gtk_widget_destroy(window5_modifier);

		//window3_reclamation=lookup_widget(button,"window3_reclamation");
		window3_reclamation=create_window3_reclamation();

		gtk_widget_show(window3_reclamation);
		gtk_widget_destroy(window5_modifier);

		treeview1=lookup_widget(window3_reclamation,"treeview1");
		afficher_rec(treeview1,"fichier.txt");

		treeview2=lookup_widget(window3_reclamation,"treeview2");
		afficher_rec(treeview2,"fichier.txt");

			
			
	   } else  {
		
		sprintf(texte,"❌ Cet id n'existe pas\n");
		output = lookup_widget(button,"label80");
		GdkColor color;
		gdk_color_parse ("#ff250d", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output),texte);
	   }

	

}

/////////////////////a verifier////////////////////////////
void
on_cherchi_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{


GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelnom;
GtkWidget *nbResultat;
GtkWidget *message;
char nom[30];
char chnb[30];
int b=0,nb;
entry=lookup_widget(button,"entrynomi2");
labelnom=lookup_widget(button,"labelnomii");
p1=lookup_widget(button,"treeview2");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(entry)));

if(strcmp(nom,"")==0){
  gtk_widget_show (labelnom);b=0;
}else{
b=1;
gtk_widget_hide (labelnom);}

if(b==0){return;}else{

nb=Chercher(p1,"fichier.txt",nom);
/* afficher le nombre de resultats obtenue par la recherche */
sprintf(chnb,"%d",nb);//conversion int==> chaine car la fonction gtk_label_set_text naccepte que chaine
nbResultat=lookup_widget(button,"nbi");
message=lookup_widget(button,"messageresi");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

gtk_widget_show (nbResultat);
gtk_widget_show (message);

}


}


void
on_treeview_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}

////////////////////////a corriger////////////////////////
void
on_button9_valide_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *input;
	GtkWidget *output,*treeview2;
	reclamation rec;
	char texte[100],id[100];

	input = lookup_widget(button,"entry8_idrec");
	strcpy(rec.idrec,gtk_entry_get_text(GTK_ENTRY(input)));
	if(exist(rec.idrec) && verif == 1)
             {
		supprimer(rec);		
		sprintf(texte,"✔️ Votre suppression à été effectué avec succés\n");
		output = lookup_widget(button,"labelmessage");
		GdkColor color;
		gdk_color_parse ("#40e61a", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output),texte);
		GtkWidget *window7_supprimer;
		GtkWidget *window3_reclamation;
		window7_supprimer=lookup_widget(button,"window7_supprimer");
		window3_reclamation =create_window3_reclamation ();
		gtk_widget_show(window3_reclamation);
		gtk_widget_destroy(window7_supprimer);
		GtkWidget *treeview1;
		treeview1=lookup_widget(window3_reclamation,"treeview1");
		afficher_rec(treeview1,"fichier.txt");

		treeview2=lookup_widget(window3_reclamation,"treeview2");
		afficher_rec(treeview2,"fichier.txt");
		verif = 0;
	   }
	else{
		sprintf(texte,"❌ Réctifier le ID et/ou cocher la case de vérification\n");
		output = lookup_widget(button,"labelmessage");
		GdkColor color;
		gdk_color_parse ("#ff250d", &color);
		gtk_widget_modify_fg (output, GTK_STATE_NORMAL, &color);
    		gtk_label_set_text(GTK_LABEL(output),texte);	
	} 

////////////////////////////////////////////////////////////////////////////





}


void
on_checkbutton_verif_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(verif == 0) {
		verif = 1;
	} else if(verif == 1) {
		verif = 0;
	}
}

