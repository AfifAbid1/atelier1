#include <gtk/gtk.h>


void
on_button1_valider_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_entrer_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_ajout_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_valide_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton11_hebergement_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton12_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_heb_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_res_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button2_chercher_clicked            (GtkButton       *button,
                                        gpointer         user_data);
/*
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);*/

void
on_button4_retourner_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_modif_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_annuler_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_modifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_annuler_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_annuler_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_ajout_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_ajout_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_modif_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_cherchi_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button9_valide_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton_verif_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
