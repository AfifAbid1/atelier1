#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "fonction.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<gtk/gtk.h>

GtkListStore *adstore;/*creation du modele de type liste*/
GtkTreeViewColumn *adcolumn;/*visualisation des colonnes*/
GtkCellRenderer *cellad;/*afficheur de cellule(text,image..)*/

enum
{
	ID,
	IDREC,
	RECLAMATION1,
	NOTE,
	TYPE,
	COLUMNS
};


//fonction ajouter reclamation
void ajouter(reclamation rec)
{
	FILE *f;
	f=fopen("fichier.txt","a+");
	if (f!=NULL)
	{
		fprintf(f,"%s %s %s %d %s \n",rec.idrec,rec.id,rec.type,rec.note,rec.reclamation1);

		fclose(f);
		
	}
	else 
	{
		printf("\n Erreur : Non trouvé");

	}
}

//modifier
void modifier(reclamation rec)
{

	FILE*f=fopen("fichier.txt","r");
	FILE*f1=fopen("ancienscap.txt","w+");
	reclamation rec1;
	while(fscanf(f,"%s %s %s %d %s \n",rec1.idrec,rec1.id,rec1.type,&rec1.note,rec1.reclamation1)!=EOF)
	{
		if(strcmp(rec1.idrec,rec.idrec)==0)
		{
			fprintf(f1,"%s %s %s %d %s \n",rec.idrec,rec.id,rec.type,rec.note,rec.reclamation1);
		}
		else{
			fprintf(f1,"%s %s %s %d %s \n",rec1.idrec,rec1.id,rec1.type,rec1.note,rec1.reclamation1);
		}
	}
	fclose(f);
	fclose(f1);
	remove("fichier.txt");
	rename("ancienscap.txt","fichier.txt");

}


//supprimer
void supprimer(reclamation rec) 
{
	reclamation rec1;	
	FILE *f1;
	FILE *f2;
	f1=fopen("fichier.txt","r");
	f2=fopen("aux.txt","w+");
	if((f1==NULL)||(f2==NULL))
		return;
	else
	{
		while(fscanf(f1,"%s %s %s %d %s \n",rec1.idrec,rec1.id,rec1.type,&rec1.note,rec1.reclamation1)!=EOF)
		{
			if(strcmp(rec.idrec,rec1.idrec)!=0)
			{
				fprintf(f2,"%s %s %s %d %s \n",rec1.idrec,rec1.id,rec1.type,rec1.note,rec1.reclamation1);
			}
		}
	}
	fclose(f1);
	fclose(f2);
	remove("fichier.txt");
	rename("aux.txt","fichier.txt");
}



//existe
int exist(char *id){
	FILE*f=NULL;
	reclamation rec;
	f=fopen("fichier.txt","r");
	while(fscanf(f,"%s %s %s %d %s \n",rec.idrec,rec.id,rec.type,&rec.note,rec.reclamation1)!=EOF)
	{
			if(strcmp(rec.idrec,id)==0)
			return 1;
	}
	fclose(f);
	return 0;
}


//chercher
int Chercher(GtkWidget* treeview1,char* l,char* nom)
{

	reclamation rec ;
	int nb=0,j=0;
	FILE* f;
        /* Creation du modele */
        adstore = gtk_list_store_new(5,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_INT,
                                     G_TYPE_STRING);
        /* Insertion des elements */
        f=fopen(l,"r");
	while(fscanf(f,"%s %s %s %d %s \n",rec.idrec,rec.id,rec.type,&rec.note,rec.reclamation1)!=EOF){
		if( strcmp(nom,rec.type)==0){ 
			nb++;
			GtkTreeIter pIter;
			 /* Creation de la nouvelle ligne */
			 gtk_list_store_append(adstore, &pIter);
			 /* Mise a jour des donnees */
			 gtk_list_store_set(adstore, &pIter,
		                    0,rec.idrec,
		                    1,rec.id,
		                    2,rec.type,
		                    3,rec.note,
		                    4,rec.reclamation1,
		                    -1);
		}
	}
        fclose(f);

	/* Creation de la 1ere colonne */
	if(j==0){
		cellad = gtk_cell_renderer_text_new();
        	adcolumn = gtk_tree_view_column_new_with_attributes("ID de reclamation",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);


        /* Ajouter la 1er colonne à la vue */
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);


	/* Creation de la 2eme colonne */
        	cellad = gtk_cell_renderer_text_new();
        	adcolumn = gtk_tree_view_column_new_with_attributes("Votre ID",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
		/* Ajouter la 2emme colonne à la vue */
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

		/* Creation de la 3eme colonne */
		cellad = gtk_cell_renderer_text_new();
		adcolumn = gtk_tree_view_column_new_with_attributes("Type",
		                                                    cellad,
		                                                    "text", 2,
		                                                    NULL);
		/* Ajouter la 3emme colonne à la vue */
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);


		/* Creation de la 4eme colonne */
		cellad = gtk_cell_renderer_text_new();
		adcolumn = gtk_tree_view_column_new_with_attributes("Note",
		                                                    cellad,
		                                                    "text", 3,
		                                                    NULL);
		/* Ajouter la 4emme colonne à la vue */
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	      /* Creation de la 5eme colonne */
		cellad = gtk_cell_renderer_text_new();
		adcolumn = gtk_tree_view_column_new_with_attributes("Reclamation",
		                                                    cellad,
		                                                    "text", 4,
		                                                    NULL);
		/* Ajouter la 5emme colonne à la vue */
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);




		j++;
	}


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview1),
                                  GTK_TREE_MODEL(adstore));
	return nb;
}





void afficher_rec(GtkWidget* treeview1,char*l)
{

	reclamation rec;	
	FILE *f;
	int i;


        /* Creation du modele */
        adstore = gtk_list_store_new(5,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_INT,
                                     G_TYPE_STRING);
        /* Insertion des elements */
        f=fopen(l,"r");
while(fscanf(f,"%s %s %s %d %s \n",rec.idrec,rec.id,rec.type,&rec.note,rec.reclamation1)!=EOF)
        {GtkTreeIter pIter;

         /* Creation de la nouvelle ligne */
         gtk_list_store_append(adstore, &pIter);
         /* Mise a jour des donnees */
         gtk_list_store_set(adstore, &pIter,
                            0,rec.idrec,
                            1,rec.id,
                            2,rec.type,
                            3,rec.note,
                            4,rec.reclamation1,
                            -1);}
        fclose(f);

	/* Creation de la 1ere colonne */
if(i==0)
	{cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("ID de reclamation",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);


        /* Ajouter la 1er colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);


	/* Creation de la 2eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("Votre ID",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
	/* Ajouter la 2emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	/* Creation de la 3eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("Type",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);
	/* Ajouter la 3emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);


	/* Creation de la 4eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("Note",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);
	/* Ajouter la 4emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

      /* Creation de la 5eme colonne */
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("Reclamation",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);
	/* Ajouter la 5emme colonne à la vue */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);




	i++;}


 	gtk_tree_view_set_model ( GTK_TREE_VIEW (treeview1),
                                  GTK_TREE_MODEL(adstore)  );

}





/*
char* service_plus_reclame(char* l) {
	{}
	reclamation rec;
	int type1=0,type2=0;	
	FILE *f = NULL;
	f = fopen(l,"r");
	if(f!=NULL){
		while(fscanf(f,"%s %s %s %d %s \n",rec.idrec,rec.id,rec.type,&rec.note,rec.reclamation1)!=EOF){
			if( strcmp("hebergement",rec.type)==0){ 
				type1++;
			} else if( strcmp("restauration",rec.type)==0){ 
				type2++;
			}
		}
	}
	if(type1>type2) {
		return "hebergement";
	} else if(type1<type2) {
		return "restauration";
	} else {
		return "égalité";
	}
}*/

