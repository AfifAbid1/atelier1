#include <string.h>
#include "greeting.h"
void sayHello(char name [], char hello []){
strcpy(hello,"Hello");
strcat(hello,name);

}
