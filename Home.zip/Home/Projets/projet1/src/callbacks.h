#include <gtk/gtk.h>


void
on_buttonHello_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
