
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"fonction.h"
#include"callbacks.h"
 #include<gtk/gtk.h>
void ajouter_stock(stockage st, char fichier[] )
{
FILE*f;

f=fopen(fichier,"a+");
if(f!=NULL)
{
fprintf(f,"%s %d %s %s %s %d %d %d %d %d %d \n ",st.referance,st.quantite,st.nom,st.type,st.etat,st.da.jour,st.da.mois,st.da.annee,st.dx.jour,st.dx.mois,st.dx.annee);
fclose(f);
}
else 
printf("Impossible d'ouvrir le fichier");
}

void modifier(stockage st , char fichier[])
{
FILE*f1;
FILE*f2;
stockage st2 ;
f1=fopen(fichier,"r");
f2=fopen("aux.txt","w+");
if((f1!=NULL)&&(f2!=NULL))
{
while(fscanf(f1,"%s %d %s %s %s %d %d %d %d %d %d \n ",st2.referance,&st2.quantite,st2.nom,st2.type,st2.etat,&st2.da.jour,&st2.da.mois,&st2.da.annee,&st2.dx.jour,&st2.dx.mois,&st2.dx.annee)!=EOF)
{
if(strcmp(st2.referance,st.referance)!=0)
fprintf(f2,"%s %d %s %s %s %d %d %d %d %d %d \n",st2.referance,st2.quantite,st2.nom,st2.type,st2.etat,st2.da.jour,st2.da.mois,st2.da.annee,st2.dx.jour,st2.dx.mois,st2.dx.annee);
else
fprintf(f2,"%s %d %s %s %s %d %d %d %d %d %d \n ",st.referance,st.quantite,st.nom,st.type,st.etat,st.da.jour,st.da.mois,st.da.annee,st.dx.jour,st.dx.mois,st.dx.annee);
}
}
fclose(f1);
fclose(f2);
remove(fichier);
rename("aux.txt",fichier);
}

void supprimer ( char referance[] , char fichier[])
{
stockage st;
FILE*f1=NULL;
FILE*f2=NULL;
f1=fopen(fichier,"r");
f2=fopen("aux.txt","w+");
while(fscanf(f1,"%s %d %s %s %s %d %d %d %d %d %d \n ",st.referance,&st.quantite,st.nom,st.type,st.etat,&st.da.jour,&st.da.mois,&st.da.annee,&st.dx.jour,&st.dx.mois,&st.dx.annee)!=EOF)
{
if(strcmp(referance , st.referance)!=0)
fprintf(f2,"%s %d %s %s %s %d %d %d %d %d %d \n ",st.referance,st.quantite,st.nom,st.type,st.etat,st.da.jour,st.da.mois,st.da.annee,st.dx.jour,st.dx.mois,st.dx.annee);
}
fclose(f1);
fclose(f2);
remove(fichier);
rename("aux.txt",fichier);
}

stockage  chercher (char ref[] , char fichier[] )
{FILE *f=NULL;
stockage st;
f=fopen(fichier,"r");
while(fscanf(f,"%s %d %s %s %s %d %d %d %d %d %d \n ",st.referance,&st.quantite,st.nom,st.type,st.etat,&st.da.jour,&st.da.mois,&st.da.annee,&st.dx.jour,&st.dx.mois,&st.dx.annee)!=EOF)
  {
      if(strcmp(st.referance,ref)==0)
         {fclose(f);
          return(st);}
  } 
}

enum{ 
REF,
QTE,
NOM,
TYPE,
ETAT,
DA,
DX,
COLUMNS
};
void afficher_produits(GtkWidget *liste,char fichier[])
{stockage e;
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char ch1[11],ch2[11],ch3[5];
FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("reference",renderer,"text",REF,NULL);//nom du colonne"reference"
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);////
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",QTE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_resizable(column,TRUE);//////////////////
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Type",renderer,"text",TYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Etat",renderer,"text",ETAT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("date d'ajout",renderer,"text",DA,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("date d'expiration",renderer,"text",DX,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING);
f=fopen(fichier,"r");
if(f==NULL){return;}
else

{ f = fopen(fichier,"a+");
		while(fscanf(f,"%s %d %s %s %s %d %d %d %d %d %d \n ",e.referance,&e.quantite,e.nom,e.type,e.etat,&e.da.jour,&e.da.mois,&e.da.annee,&e.dx.jour,&e.dx.mois,&e.dx.annee)!=EOF)
	{sprintf(ch1,"%d/%d/%d",e.da.jour,e.da.mois,e.da.annee);
	 sprintf(ch2,"%d/%d/%d",e.dx.jour,e.dx.mois,e.dx.annee);
	 sprintf(ch3,"%d",e.quantite);
	
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,REF,e.referance,QTE,ch3,NOM,e.nom,TYPE,e.type,ETAT,e.etat,DA,ch1,DX,ch2,-1);
	}


	fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

void repture (char fichier[])
{FILE *f=NULL;
FILE *f2=NULL;
stockage e;
f=fopen(fichier,"r");
f2=fopen("repture.txt","w");
if(f!=NULL)
    {while(fscanf(f,"%s %d %s %s %s %d %d %d %d %d %d \n ",e.referance,&e.quantite,e.nom,e.type,e.etat,&e.da.jour,&e.da.mois,&e.da.annee,&e.dx.jour,&e.dx.mois,&e.dx.annee)!=EOF)
       if(e.quantite==0)
         fprintf(f2,"%s %d %s %s %s %d %d %d %d %d %d \n ",e.referance,e.quantite,e.nom,e.type,e.etat,e.da.jour,e.da.mois,e.da.annee,e.dx.jour,e.dx.mois,e.dx.annee);
     fclose(f);
     fclose(f2);
    }
}

