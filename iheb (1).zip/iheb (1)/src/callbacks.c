#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
 int x=0,x2=0;
int y1=0,y2=0;
void
on_Modifier_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *windowmod;
GtkWidget *windowmen;

windowmen = lookup_widget(button,"windowmenu");
gtk_widget_destroy(windowmen);

windowmod = lookup_widget(button,"windowmodification");
windowmod = create_windowmodification();
gtk_widget_show(windowmod);

}

void
on_Afficher_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview;
GtkWidget *windowaff;
GtkWidget *windowmen;

windowmen = lookup_widget(button,"windowmenu");
gtk_widget_destroy(windowmen);

windowaff = lookup_widget(button,"windowaffichage");
windowaff = create_windowaffichage();
gtk_widget_show(windowaff);

treeview = lookup_widget(windowaff, "treeviewafficher");
afficher_produits(treeview,"produit.txt");

}
/*_____________________________________________*/

void
on_Supprimer_clicked                   (GtkWidget       *button,gpointer         user_data)
{
GtkWidget *treeview;
GtkWidget *windowsupp;
GtkWidget *windowmen;
windowmen = lookup_widget(button,"windowmenu");
gtk_widget_destroy(windowmen);

windowsupp = lookup_widget(button,"windowsuppression");
windowsupp = create_windowsuppression();
gtk_widget_show(windowsupp);
}

void
on_Ajouter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *windowaj;
GtkWidget *windowmen;

windowmen = lookup_widget(button,"windowmenu");
gtk_widget_destroy(windowmen);

windowaj = lookup_widget(button,"windowajout");
windowaj = create_windowajout();
gtk_widget_show(windowaj);
}


void
on_Repture_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview;
GtkWidget *windowrep;
GtkWidget *windowmen;
windowmen = lookup_widget(button,"windowmenu");
gtk_widget_destroy(windowmen);

windowrep = lookup_widget(button,"windowrepture");
windowrep = create_windowrepture();
gtk_widget_show(windowrep);
treeview = lookup_widget(windowrep, "treeviewrepture");
repture ("produit.txt");
afficher_produits(treeview,"repture.txt" );

}

/*_________________________________________________________*/
void
on_radiobutton_frais1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
   x=1;
}


void
on_radiobutton_gate1_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
   x=2;

}

/*______________________________________________________________________________*/
void
on_ajouter_clicked                     (GtkWidget       *button,gpointer         user_data)
{GtkWidget *input,*j,*m,*a,*c,*windowajout;
stockage s;
FILE *f;
char ch[10];

input=lookup_widget(button,"Referanceajouter");
strcpy(s.referance,gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(button,"Nomajouter");
strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(button,"Quantiteajouter");
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(input)));
s.quantite=atoi(ch);

if (x==1)
 strcpy(s.etat,"fraise");
else
if(x==2)
strcpy(s.etat,"Gaté");
///combo
c=lookup_widget(button,"comboboxajouter");
strcpy(s.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(c)));
////spin 
j=lookup_widget(button,"jour1");
m=lookup_widget(button,"mois1");
a=lookup_widget(button,"annee1");
s.da.jour =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));
s.da.mois =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
s.da.annee =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));

j=lookup_widget(button,"jour2");
m=lookup_widget(button,"mois2");
a=lookup_widget(button,"annee2");
s.dx.jour =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));
s.dx.mois =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
s.dx.annee =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));

ajouter_stock(s,"produit.txt");

windowajout=lookup_widget(button,"windowajout");
gtk_widget_destroy(windowajout);
}

/*_______________________________________*/
void
on_Retourafficher_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget  *windowaff;

windowaff=lookup_widget(button,"windowaffichage");
gtk_widget_destroy(windowaff);

}


void
on_Retourrepture_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget  *windowrep;

windowrep=lookup_widget(button,"windowrepture");
gtk_widget_destroy(windowrep);

}

void
on_Retoursupprimer_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget  *windowsup;

windowsup=lookup_widget(button,"windowsuppression");
gtk_widget_destroy(windowsup);

}

void
on_Retourmodifier_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget  *windowmodif;

windowmodif=lookup_widget(button,"windowmodification");
gtk_widget_destroy(windowmodif);
}

void
on_Retourajouter_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget  *windowajout;

windowajout=lookup_widget(button,"windowajout");
gtk_widget_destroy(windowajout);
}
/*_______suppression_____________________________*/
void
on_Oksupprimer_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget* input,*windowsup;
char ref[20];

 input = lookup_widget(button, "Referancesupprimer") ;
 
 strcpy(ref,gtk_entry_get_text(GTK_ENTRY(input))); 
 supprimer(ref,"produit.txt");

windowsup=lookup_widget(button,"windowsuppression");
gtk_widget_destroy(windowsup);
}

/*______________________________*/

void
on_okreclamation_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *output;

output = lookup_widget(button, "label56") ;

if(y1==1 && y2==0)
  {gtk_label_set_text(GTK_LABEL(output),"vous avez cocher oui");
  }
 else
	if(y1==0 && y2==1)
	  {gtk_label_set_text(GTK_LABEL(output),"vous avez cocher non");
	  }
	else
	 {gtk_label_set_text(GTK_LABEL(output),"verifier votre choix");
	}
y1=0;
y2=0;
}
/*___________________________________________________*/
void
on_checkbutton_oui_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active (togglebutton))
 y1=1;

}


void
on_checkbutton_non_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active (togglebutton))
 y2=1;

}
/*__________________________________________*/
/*________chercher_____________________*/
void
on_Okchercher_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget* input;
  GtkWidget* output ;
char ref1[20],ch[6],ch2[11];
stockage e;

input = lookup_widget(button, "Referancemodifier") ;
strcpy(ref1,gtk_entry_get_text(GTK_ENTRY(input))); 
e=chercher(ref1,"produit.txt");

if(strcmp(e.referance,ref1)==0)
{
output=lookup_widget(button,"label51");
gtk_label_set_text(GTK_LABEL(output),"produit existe");

output=lookup_widget(button,"Quantitemodifier");
sprintf(ch,"%d",e.quantite);
gtk_entry_set_text(GTK_ENTRY(output),ch);

output=lookup_widget(button,"Nommodifier");
gtk_entry_set_text(GTK_ENTRY(output),e.nom);
output=lookup_widget(button,"Referancemodifier");
gtk_entry_set_text(GTK_ENTRY(output),e.referance);

output=lookup_widget(button,"label52");
gtk_label_set_text(GTK_LABEL(output),e.etat);
output=lookup_widget(button,"label53");
gtk_label_set_text(GTK_LABEL(output),e.type);

output=lookup_widget(button,"label54");
sprintf(ch2,"%d/%d/%d",e.da.jour,e.da.mois ,e.da.annee );
gtk_label_set_text(GTK_LABEL(output),ch2);

output=lookup_widget(button,"label55");
sprintf(ch2,"%d/%d/%d",e.dx.jour,e.dx.mois ,e.dx.annee );
gtk_label_set_text(GTK_LABEL(output),ch2);

}
else{
output=lookup_widget(button,"label51");
gtk_label_set_text(GTK_LABEL(output),"produit n'existe pas");
}

}

/*_____________modif___________________*/
void
on_Okmodifier_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *input,*j,*m,*a,*c,*windowmodif;
stockage s;
FILE *f;
char ch[10];

input=lookup_widget(button,"Referancemodifier");
strcpy(s.referance,gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(button,"Nommodifier");
strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(button,"Quantitemodifier");
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(input)));
s.quantite=atoi(ch);

if (x2==1)
 strcpy(s.etat,"fraise");
else
if(x2==2)
strcpy(s.etat,"Gaté");
///combo
c=lookup_widget(button,"comboboxmodifier");
strcpy(s.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(c)));
////spin 
j=lookup_widget(button,"jour3");
m=lookup_widget(button,"mois3");
a=lookup_widget(button,"annee3");
s.da.jour =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));
s.da.mois =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
s.da.annee =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));

j=lookup_widget(button,"jour4");
m=lookup_widget(button,"mois4");
a=lookup_widget(button,"annee4");
s.dx.jour =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));
s.dx.mois =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
s.dx.annee =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));

modifier(s ,"produit.txt");

windowmodif=lookup_widget(button,"windowmodification");
gtk_widget_destroy(windowmodif);

}
/*____________________________________*/

void
on_radiobutton_gate2_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
   x2=2;

}

void
on_radiobutton_frais2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
   x2=1;

}



void
on_Quittermenu_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *windowenu;
windowenu=lookup_widget(objet_graphique,"windowenu");
gtk_widget_destroy(windowenu);

}

