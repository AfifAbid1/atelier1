#include <gtk/gtk.h>


void
on_Modifier_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Afficher_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Supprimer_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Ajouter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Repture_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);
/*____________________________________________________________________*/
void
on_radiobutton_frais1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_gate1_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);
/*______________________________________*/

void
on_Retourafficher_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Retourrepture_clicked               (GtkWidget        *button,
                                        gpointer         user_data);

void
on_Retoursupprimer_clicked             (GtkWidget        *button,
                                        gpointer         user_data);

void
on_okreclamation_clicked               (GtkWidget        *button,
                                        gpointer         user_data);

void
on_Oksupprimer_clicked                 (GtkWidget        *button,
                                        gpointer         user_data);

void
on_checkbutton_oui_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_non_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);




void
on_Retourmodifier_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Okchercher_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Okmodifier_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Retourajouter_clicked               (GtkWidget       *button,
                                        gpointer         user_data);




void
on_radiobutton_gate2_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_frais2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Quittermenu_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
