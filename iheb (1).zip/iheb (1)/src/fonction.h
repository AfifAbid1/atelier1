#ifndef FONCTION_H_
#define FONCTION_H_
#include <gtk/gtk.h>
typedef struct date
{
int jour;
int mois;
int annee;
}date;
typedef struct stockage
{
char referance[20];
int quantite;
char nom[20];
char type[20];
char etat[20];
date da;
date dx;
}stockage;

void ajouter_stock(stockage st, char fichier[] );
void supprimer ( char referance[] , char fichier[]);
void modifier(stockage st , char fichier[]);
stockage chercher (char ref[] , char fichier[] );
void repture(char fichier[]);
void afficher_produits(GtkWidget *liste,char fichier[]);
#endif
