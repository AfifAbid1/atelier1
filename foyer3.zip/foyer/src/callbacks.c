#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
int x=0;
int y1=0,y2=0,y3=0;
int z1=0,z2=0,z3=0;

void
on_actualiser_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *windowacc,*treeview;

windowacc=lookup_widget(button,"acceuil");
gtk_widget_destroy(windowacc);

windowacc=lookup_widget(button,"acceuil");
windowacc=create_acceuil();
gtk_widget_show(windowacc);

treeview = lookup_widget (windowacc, "treeview1");
affiche(treeview,"etudiant.txt");
}


void
on_ajouter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *windowajout,*windowacc;

windowacc=lookup_widget(button,"acceuil");
gtk_widget_destroy(windowacc);

windowajout=create_ajout();
gtk_widget_show(windowajout);

}


void
on_Modifier_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{GtkWidget *windowmodif,*windowacc;

windowacc=lookup_widget(button,"acceuil");
gtk_widget_destroy(windowacc);

windowmodif=create_modif();
gtk_widget_show(windowmodif);

}


void
on_supprimer_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *windowsup,*windowacc;

windowacc=lookup_widget(button,"acceuil");
gtk_widget_destroy(windowacc);

windowsup=create_supprimer();
gtk_widget_show(windowsup);

}

void
on_nb_etudiant_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *windowacc,*treeview;

windowacc=lookup_widget(button,"acceuil");
gtk_widget_destroy(windowacc);

windowacc=lookup_widget(button,"acceuil");
windowacc=create_acceuil();
gtk_widget_show(windowacc);

nb_etudiant("etudiant.txt");
treeview = lookup_widget (windowacc, "treeview1");
affiche2(treeview);

}


void
on_quitter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *windowacc;

windowacc=lookup_widget(button,"acceuil");
gtk_widget_destroy(windowacc);

}


void
on_back1_clicked                       (GtkWidget      *button,
                                        gpointer         user_data)
{GtkWidget *windowacc, *windowajout;

windowajout=lookup_widget(button,"ajout");
gtk_widget_destroy(windowajout);

windowacc=create_acceuil();
gtk_widget_show(windowacc);
}


void
on_back2_clicked                       (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *windowacc, *windowsup;

windowsup=lookup_widget(button,"supprimer");
gtk_widget_destroy(windowsup);

windowacc=create_acceuil();
gtk_widget_show(windowacc);

}

void
on_back3_clicked                       (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget *windowacc, *windowmodif;

windowmodif=lookup_widget(button,"modif");
gtk_widget_destroy(windowmodif);

windowacc=create_acceuil();
gtk_widget_show(windowacc);

}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active (GTK_RADIO_BUTTON(togglebutton)))
    x=1;
}

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active (GTK_RADIO_BUTTON(togglebutton)))
    x=2;

}


void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active (GTK_RADIO_BUTTON(togglebutton)))
    x=5;
}


void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active (GTK_RADIO_BUTTON(togglebutton)))
    x=6;
}




void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active (togglebutton))
z1=1;

}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active (togglebutton))
z2=2;

}


void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active (togglebutton))
z3=3;

}


void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active (togglebutton))
y1=1;

}


void
on_checkbutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active (togglebutton))
y2=2;

}


void
on_checkbutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if(gtk_toggle_button_get_active (togglebutton))
y3=3;

}


void
on_ajout_clicked                       (GtkWidget      *button,
                                        gpointer         user_data)
{
 GtkWidget* input,*windowajout,*windowacc;
 Etudiant e;
 GtkWidget *j,*m,*a,*niv;
 GtkWidget *qte;
char ch1[5],ch2[5],ch3[5];

FILE *f=NULL;
 input = lookup_widget(button, "entry3") ; 
 strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(input))); 
 input = lookup_widget(button, "entry4") ; 
 strcpy(e.cin,gtk_entry_get_text(GTK_ENTRY(input)));  
 input = lookup_widget(button, "entry7") ; 
 strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(input))); 
 input = lookup_widget(button, "entry8") ; 
 strcpy(e.telephone,gtk_entry_get_text(GTK_ENTRY(input))); 


if(x==1)       strcpy(e.sexe,"Homme");
else if(x==2)  strcpy(e.sexe,"Femme");


qte=lookup_widget(button,"spinbutton1"); 
e.chambre=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(qte));


j=lookup_widget(button, "combobox1") ; 
strcpy(ch1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(j)));
m=lookup_widget(button, "combobox2") ; 
strcpy(ch2,gtk_combo_box_get_active_text(GTK_COMBO_BOX(m)));
a=lookup_widget(button, "combobox3") ; 
strcpy(ch3,gtk_combo_box_get_active_text(GTK_COMBO_BOX(a)));
sprintf(e.date_nais,"%s/%s/%s",ch1,ch2,ch3);
niv=lookup_widget(button, "combobox7") ; 
strcpy(e.niv,gtk_combo_box_get_active_text(GTK_COMBO_BOX(niv)));

strcpy(e.payment,"");
if(y1==1)
strcpy(e.payment,"Espèces_");
if(y2==2)
strcpy(e.payment,"Chèque");
if(y3==3)
strcpy(e.payment,"Prélèvement");


ajout("etudiant.txt",e);
windowajout=lookup_widget(button,"ajout");
gtk_widget_destroy(windowajout);

windowacc=lookup_widget(button,"acceuil");
windowacc=create_acceuil();
gtk_widget_show(windowacc);
}

void
on_sup_clicked                         (GtkWidget       *button,
                                        gpointer         user_data)
{ GtkWidget* input,*windowsup,*windowacc;
  char cin[9];

 input = lookup_widget(button, "entry1") ;
 
 strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input))); 
 supprimer("etudiant.txt",cin);

windowsup=lookup_widget(button,"supprimer");
gtk_widget_destroy(windowsup);

windowacc=lookup_widget(button,"acceuil");
windowacc=create_acceuil();
gtk_widget_show(windowacc);
}


void
on_chercher_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget* input,*output;
Etudiant e2;
  char cin[9],ch[10],ch1[10],ch2[10];

 input = lookup_widget(button,"entry2") ; 
 strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input))); 

e2=recherche("etudiant.txt",cin);


if(strcmp(e2.cin,cin)==0)
{
output=lookup_widget(button,"entry5");
gtk_entry_set_text(GTK_ENTRY(output),e2.nom);
output=lookup_widget(button,"entry6");
gtk_entry_set_text(GTK_ENTRY(output),e2.prenom);
output=lookup_widget(button,"entry9");
gtk_entry_set_text(GTK_ENTRY(output),e2.telephone);


output=lookup_widget(button,"label29");
gtk_label_set_text(GTK_LABEL(output),e2.date_nais);

output=lookup_widget(button,"label27");
gtk_label_set_text(GTK_LABEL(output),e2.sexe);

output=lookup_widget(button,"label43");
gtk_label_set_text(GTK_LABEL(output),e2.niv);

output=lookup_widget(button,"label30");
sprintf(ch1,"%d",e2.chambre);
gtk_label_set_text(GTK_LABEL(output),ch1);

output=lookup_widget(button,"label46");
gtk_label_set_text(GTK_LABEL(output),e2.payment);


output=lookup_widget(button,"label24");
gtk_label_set_text(GTK_LABEL(output),"Etudiant existe");
}
else
{output=lookup_widget(button,"label24");
gtk_label_set_text(GTK_LABEL(output),"Etudiant n'existe pas!!");}
}



void
on_modif_clicked                       (GtkWidget       *button,
                                        gpointer         user_data)
{GtkWidget* input,*windowmodif,*windowacc;
 Etudiant e1;
 GtkWidget *j,*m,*a,*niv;
 GtkWidget *qte;
char ch1[5],ch2[5],ch3[5];

 input = lookup_widget(button, "entry2") ; 
 strcpy(e1.cin,gtk_entry_get_text(GTK_ENTRY(input))); 
 input = lookup_widget(button, "entry5") ; 
 strcpy(e1.nom,gtk_entry_get_text(GTK_ENTRY(input)));  
 input = lookup_widget(button, "entry6") ; 
 strcpy(e1.prenom,gtk_entry_get_text(GTK_ENTRY(input)));  
 input = lookup_widget(button, "entry9") ; 
 strcpy(e1.telephone,gtk_entry_get_text(GTK_ENTRY(input)));  


if(x==5)       strcpy(e1.sexe,"Homme");
else if(x==6)  strcpy(e1.sexe,"Femme");


qte=lookup_widget(button,"spinbutton3"); 

e1.chambre=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(qte));


j=lookup_widget(button, "combobox4") ; 
strcpy(ch1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(j)));
m=lookup_widget(button,"combobox5") ; 
strcpy(ch2,gtk_combo_box_get_active_text(GTK_COMBO_BOX(m)));
a=lookup_widget(button, "combobox6") ; 
strcpy(ch3,gtk_combo_box_get_active_text(GTK_COMBO_BOX(a)));
sprintf(e1.date_nais,"%s/%s/%s",ch1,ch2,ch3);
niv=lookup_widget(button, "combobox8") ; 
strcpy(e1.niv,gtk_combo_box_get_active_text(GTK_COMBO_BOX(niv)));

strcpy(e1.payment," ");
if(z1==1)
strcpy(e1.payment,"Espèces");
if(z2==2)
strcpy(e1.payment,"Chèque");
if(z3==3)
strcpy(e1.payment,"Prélèvement");

modif("etudiant.txt",e1);
windowmodif=lookup_widget(button,"modif");
gtk_widget_destroy(windowmodif);

windowacc=lookup_widget(button,"acceuil");
windowacc=create_acceuil();
gtk_widget_show(windowacc);
}






