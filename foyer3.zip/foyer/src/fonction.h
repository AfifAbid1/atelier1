#ifndef FONCTION_H_
#define FONCTION_H_
#include <gtk/gtk.h>

struct etudiant{
char nom[20];
char prenom[20];
char cin[9];
char  telephone[9];
char date_nais[11];
char sexe[10];
char niv[10];
int chambre;
char payment[100];
};typedef struct etudiant Etudiant;

void ajout(char nom_fich[], Etudiant e);
Etudiant recherche(char nom_fich[],char cin[]);
void supprimer(char nom_fich[],char cin[]);
void modif(char nom_fich[],Etudiant e);
void affiche(GtkWidget *liste,char nom_fich[]);
void nb_etudiant(char nom_fich[]);
void affiche2(GtkWidget *liste);
 #endif
