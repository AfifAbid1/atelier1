#include <stdio.h> 
#include <string.h> 
#include "fonction.h"

#include <errno.h>
#include <stdlib.h>
#include <stdbool.h>
#include "callbacks.h"
#include <gtk/gtk.h>

void ajout(char nom_fich[], Etudiant e)
{FILE *f=NULL;
f=fopen(nom_fich,"a");
if(f!=NULL)
 {
  fprintf(f,"%s %s %s %s %s %s %s %d \n",e.nom,e.prenom,e.cin,e.telephone,e.date_nais,e.sexe,e.niv,e.chambre); 
  fclose(f);
 }
}

Etudiant recherche(char nom_fich[],char cin[])
{FILE *f=NULL;
Etudiant e1;
f=fopen(nom_fich,"r");
if(f!=NULL)
{
   while(fscanf(f,"%s %s %s %s %s %s %s %d \n",e1.nom,e1.prenom,e1.cin,e1.telephone,e1.date_nais,e1.sexe,e1.niv,&e1.chambre)!=EOF)
      if(strcmp(e1.cin,cin)==0)
         {fclose(f);
          return(e1);}
}
}

void supprimer(char nom_fich[],char cin[])
{FILE *f=NULL;
FILE *f2=NULL;
Etudiant e1;

f=fopen(nom_fich,"r");
f2=fopen("etudiant2.txt","w");
if(f!=NULL)
  while(fscanf(f,"%s %s %s %s %s %s %s %d \n",e1.nom,e1.prenom,e1.cin,e1.telephone,e1.date_nais,e1.sexe,e1.niv,&e1.chambre)!=EOF)
      if(strcmp(e1.cin,cin)!=0)
         fprintf(f2,"%s %s %s %s %s %s %s %d \n",e1.nom,e1.prenom,e1.cin,e1.telephone,e1.date_nais,e1.sexe,e1.niv,e1.chambre);
fclose(f);
fclose(f2);
remove(nom_fich); 
rename("etudiant2.txt",nom_fich);
}

void modif(char nom_fich[],Etudiant e)
{FILE *f=NULL;
FILE *f2=NULL;
Etudiant e1;

f=fopen(nom_fich,"r");
f2=fopen("etudiant2.txt","w");
if(f!=NULL)
  {while(fscanf(f,"%s %s %s %s %s %s %s %d \n",e1.nom,e1.prenom,e1.cin,e1.telephone,e1.date_nais,e1.sexe,e1.niv,&e1.chambre)!=EOF)
      if(strcmp(e1.cin,e.cin)==0)
         fprintf(f2,"%s %s %s %s %s %s %s %d \n",e.nom,e.prenom,e.cin,e.telephone,e.date_nais,e.sexe,e.niv,e.chambre); 
      else
         fprintf(f2,"%s %s %s %s %s %s %s %d \n",e1.nom,e1.prenom,e1.cin,e1.telephone,e1.date_nais,e1.sexe,e1.niv,e1.chambre);
   fclose(f);
   fclose(f2);
   remove(nom_fich); 
   rename("etudiant2.txt",nom_fich);
   }
}



enum{ 
NOM,
PRENOM,
CIN,
TELEPHONE,
DATE,
SEXE,
NIV,
CHAMBRE,
COLUMNS
};

void affiche(GtkWidget *liste,char nom_fich[])
{Etudiant e1;
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char ch1[10],ch2[10],ch3[10];
FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",PRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("CIN",renderer,"text",CIN,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_resizable(column,TRUE);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Telephone",renderer,"text",TELEPHONE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Sexe",renderer,"text",SEXE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Niveau",renderer,"text",NIV,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Chambre",renderer,"text",CHAMBRE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);
}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING);
f=fopen(nom_fich,"r");
if(f==NULL){return;}
else
 { f = fopen(nom_fich,"a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %d \n",e1.nom,e1.prenom,e1.cin,e1.telephone,e1.date_nais,e1.sexe,e1.niv,&e1.chambre)!=EOF)
	{sprintf(ch1,"%d",e1.chambre);
	
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,NOM,e1.nom,PRENOM,e1.prenom,CIN,e1.cin,TELEPHONE,e1.telephone,DATE,
	e1.date_nais,SEXE,e1.sexe,NIV,e1.niv,CHAMBRE,ch1,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
 }
}

void nb_etudiant(char nom_fich[])
{FILE *f,*f2;
Etudiant e1;
int x1=0,x2=0,x3=0,x4=0,x5=0;
f=fopen(nom_fich,"r");
f2=fopen("nb_etudiant.txt","w");

	while(fscanf(f,"%s %s %s %s %s %s %s %d \n",e1.nom,e1.prenom,e1.cin,e1.telephone,e1.date_nais,e1.sexe,e1.niv,&e1.chambre)!=EOF)
	{if(strcmp(e1.niv,"1er")==0)
            x1++;
   	else 
	    if(strcmp(e1.niv,"2eme")==0)
		x2++;
	else 
	    if(strcmp(e1.niv,"3eme")==0)
		x3++;
	else 
	    if(strcmp(e1.niv,"4eme")==0)
		x4++;
	else 
	    if(strcmp(e1.niv,"5eme")==0)
		x5++;
	}
fprintf(f2,"%d %d %d %d %d \n",x1,x2,x3,x4,x5);
fclose(f);
fclose(f2);
}


enum{ 
NIV1,
NIV2,
NIV3,
NIV4,
NIV5,
COLUMNS1
};

void affiche2(GtkWidget *liste)
{Etudiant e1;
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char ch1[10],ch2[10],ch3[10],ch4[10],ch5[10];
int x1,x2,x3,x4,x5;
FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("1er",renderer,"text",NIV1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("2eme",renderer,"text",NIV2,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("3eme",renderer,"text",NIV3,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_resizable(column,TRUE);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("4eme",renderer,"text",NIV4,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("5eme",renderer,"text",NIV5,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);
}

store=gtk_list_store_new(COLUMNS1,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("nb_etudiant.txt","r");
if(f==NULL){return;}
else
 { f = fopen("nb_etudiant.txt","a+");
     while(fscanf(f,"%d %d %d %d %d \n",&x1,&x2,&x3,&x4,&x5)!=EOF)
	{sprintf(ch1,"%d",x1);
	 sprintf(ch2,"%d",x2);
	 sprintf(ch3,"%d",x3);
	 sprintf(ch4,"%d",x4);
	 sprintf(ch5,"%d",x5);
	
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,NIV1,ch1,NIV2,ch2,NIV3,ch3,NIV4,ch4,NIV5,ch5,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
 }
}
/*______________________________________________________________________________________________*/
