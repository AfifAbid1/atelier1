#include <gtk/gtk.h>


void
on_actualiser_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkWidget      *button,
                                        gpointer         user_data);

void
on_Modifier_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);
void
on_nb_etudiant_clicked                 (GtkWidget       *button,
					gpointer         user_data);

void
on_quitter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);


void
on_back1_clicked                       (GtkWidget      *button,
                                        gpointer         user_data);

void
on_back2_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_back3_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajout_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);


void
on_modif_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);
void
on_sup_clicked                         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
